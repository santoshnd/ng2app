import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TemplateService } from './template.service';
import { Template1Component } from './template1/template1.component';
import { TemplateDetailComponent } from './template-detail/template-detail.component';
import { MessagesComponent } from './messages/messages.component';
import { MessageService } from './message.service';


@NgModule({
  declarations: [
    AppComponent,
    Template1Component,
    TemplateDetailComponent,
    MessagesComponent
  ],
  imports: [
	BrowserModule,
	FormsModule
  ],
  providers: [TemplateService, MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
