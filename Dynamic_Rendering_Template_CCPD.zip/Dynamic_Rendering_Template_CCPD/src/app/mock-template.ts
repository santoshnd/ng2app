import { Template } from './template';

export const TEMPLATES: Template[] = [
  { 'id': 1, 'name': 'template1' ,'section1': 'col-lg-12', 'section2': 'col-lg-4', 'section3': 'col-lg-8', 'section4': 'col-lg-12', 'section5': 'hide', 'section6': 'hide', 'section7': 'hide' },
  { 'id': 2, 'name': 'template2','section1': 'col-lg-12', 'section2': 'col-lg-6', 'section3': 'col-lg-6', 'section4': 'col-lg-12', 'section5': 'hide', 'section6': 'hide', 'section7': 'hide' },
  { 'id': 3, 'name': 'template3','section1': 'col-lg-12', 'section2': 'col-lg-6', 'section3': 'col-lg-6', 'section4': 'col-lg-6', 'section5': 'col-lg-6', 'section6': 'col-lg-12', 'section7': 'hide' },
  { 'id': 4, 'name': 'template4', 'section1': 'col-lg-12', 'section2': 'col-lg-4', 'section3': 'col-lg-4', 'section4': 'col-lg-4', 'section5': 'col-lg-6', 'section6': 'col-lg-6', 'section7': 'col-lg-12'},
{ 'id': 5, 'name': 'template5', 'section1': 'col-lg-6', 'section2': 'col-lg-2', 'section3': 'col-lg-4', 'section4': 'col-lg-12', 'section5': 'col-lg-8', 'section6': 'col-lg-3', 'section7': 'col-lg-1'}


  ];