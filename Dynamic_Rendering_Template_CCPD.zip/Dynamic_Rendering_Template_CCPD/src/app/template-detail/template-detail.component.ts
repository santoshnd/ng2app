import { Component, OnInit, Input } from '@angular/core';


import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Template } from '../template';

@Component({
  selector: 'app-template-detail',
  templateUrl: './template-detail.component.html',
  styleUrls: ['./template-detail.component.css']
})
export class TemplateDetailComponent implements OnInit {
	@Input() template: Template;

	/* getTemplateStructure() : void {
        var templateStructure = "{ 'template1': { 'section1': 'col-lg-12', 'section2': 'col-lg-4', 'section3': 'col-lg-8', 'section4': 'col-lg-12', 'section5': 'hide', 'section6': 'hide', 'section7': 'hide' }, 'template2': { 'section1': 'col-lg-12', 'section2': 'col-lg-6', 'section3': 'col-lg-6', 'section4': 'col-lg-12', 'section5': 'hide', 'section6': 'hide', 'section7': 'hide' }, 'template3': { 'section1': 'col-lg-12', 'section2': 'col-lg-6', 'section3': 'col-lg-6', 'section4': 'col-lg-6', 'section5': 'col-lg-6', 'section6': 'col-lg-12', 'section7': 'hide' }, 'template4': { 'section1': 'col-lg-12', 'section2': 'col-lg-4', 'section3': 'col-lg-4', 'section4': 'col-lg-4', 'section5': 'col-lg-6', 'section6': 'col-lg-6', 'section7': 'col-lg-12' } }";
		console.log(templateStructure);
    } */

  constructor() { }

  ngOnInit() {
	  //this.getTemplateStructure();
  }

}
