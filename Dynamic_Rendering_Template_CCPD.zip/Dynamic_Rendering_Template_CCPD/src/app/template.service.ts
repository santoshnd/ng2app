import { Injectable } from '@angular/core';
import { Template } from './template';
import { TEMPLATES } from './mock-template';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { MessageService } from './message.service';
@Injectable()
export class TemplateService {

	getTemplates(): Observable<Template[]> {
		//this.messageService.add('TemplateService: fetched TEMPLATES');
		return of(TEMPLATES);
	}

  constructor(private messageService: MessageService) { }

}
