import { Component, OnInit } from '@angular/core';
import { Template } from '../template';
import { TEMPLATES } from '../mock-template';
import { TemplateService } from '../template.service';
@Component({
  selector: 'app-template1',
  templateUrl: './template1.component.html',
  styleUrls: ['./template1.component.css']
})
export class Template1Component implements OnInit {
	templates: Template[];
	
	selectedTemplate: Template;

	hack(val) {
	  return Array.from(val);
	}
	getTemplates(): void {
	  this.templateService.getTemplates()
        .subscribe(templates => this.templates = templates);
	}
	
	constructor(private templateService: TemplateService) { }
	ngOnInit() {
		this.getTemplates();
	}
	onSelect(template: Template): void {
	  this.selectedTemplate = template;
	}

}
