import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SimplePaginationComponent } from './simple-pagination/simple-pagination.component';
import { MyPaginationComponent } from './my-pagination/my-pagination.component';
import { BaseComponentComponent } from './base-component/base-component.component';
import {TlistComponent } from './tlist/tlist.component';
import { TListComponentDemo} from './tlist/tlist.component.demo';
import { RuntimeContentComponent} from './runtime-content/runtime-content.component';
import { RuntimeContentComponentDemo } from './runtime-content/runtime-content.component.demo';
import { DynamicContentComponent,TextBoxComponent, 
  DynamicSample2Component, 
  UnknownDynamicComponent  } from './dynamic-content/dynamic-content.component';
import {DynamicContentComponentDemo  } from './dynamic-content/dynamic-content.component.demo';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    TlistComponent, 
    TListComponentDemo,

    DynamicContentComponent, 
    TextBoxComponent, 
    DynamicSample2Component, 
    UnknownDynamicComponent,
    DynamicContentComponentDemo,

    RuntimeContentComponent,
    RuntimeContentComponentDemo
    
    
    
    
    
    
    
  ],
  entryComponents: [
    TextBoxComponent, 
    DynamicSample2Component, 
    UnknownDynamicComponent,
    DynamicContentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
