import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'base-component',
  template: `
    <p>
      base-component Works!
    </p>
  `,
  styleUrls: ['./base-component.component.css']
})
export class BaseComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
