import {  Component, Input, OnInit, OnDestroy, 
    ViewChild, ViewContainerRef, 
    ComponentFactoryResolver, ComponentRef } from '@angular/core';

    import { DynamicContentComponent,TextBoxComponent, 
        DynamicSample2Component, 
        UnknownDynamicComponent  } from './dynamic-content.component';    
    
@Component({
    selector: 'dynamic-component-demo',
    /*
    template: `
        <div>
            <h2>Dynamic content</h2>
            <h3>Context: <input type="text" [(ngModel)]="context.text"></h3>
            <dynamic-content type={{type}} [context]="context"></dynamic-content>
            <dynamic-content type="sample2" [context]="context"></dynamic-content>
            <dynamic-content type="some-other-type" [context]="context"></dynamic-content>
        </div>
    `
    */
    template: `
    <div #container>
    <dynamic-content type={{type}} [context]="context"></dynamic-content>
    </div>
`
  })
  export class DynamicContentComponentDemo {
    @ViewChild('container', { read: ViewContainerRef })
    container: ViewContainerRef;

    private componentRef: ComponentRef<{}>;

    constructor(
        private componentFactoryResolver: ComponentFactoryResolver) {
    }
    
    type="textbox";
    
    context: any = {
        text: 'test',
        type:'textbox',
        seq: "1",
        id: "ARXELOZ-LOST-COUNTRY",
        control: "Hidden",
        reqIndicator: "false",
        maxChars: "3",
        value: "No",
        label: "Country Of Loss"
    }
    myJSON =[{
        "-seq": "1",
        "-id": "ARXELOZ-LOST-COUNTRY",
        "-control": "Hidden",
        "-type": "Alphanumeric",
        "-reqIndicator": "false",
        "-maxChars": "3",
        "value": { "-xsi:nil": "true" },
        "label": "Country Of Loss"
      },
      {
        "-seq": "1",
        "-id": "ARXELOZ-LOST-DATE",
        "-control": "Hidden",
        "-type": "Date",
        "-reqIndicator": "false",
        "-maxChars": "7",
        "value": { "-xsi:nil": "true" },
        "label": "Loss Date"
      },
      {
        "-seq": "1",
        "-id": "ARXELOZ-LOST-POLICE-REF-NBR",
        "-control": "Hidden",
        "-type": "Alphanumeric",
        "-reqIndicator": "false",
        "-maxChars": "33",
        "value": { "-xsi:nil": "true" },
        "label": "Police Ref Number"
      }];
  
      ngAfterViewInit() {

        let factory = this.componentFactoryResolver.resolveComponentFactory(DynamicContentComponent);
        this.componentRef = this.container.createComponent(factory);

        // set component context
        let instance = <DynamicContentComponent> this.componentRef.instance;
        instance.context = this.context;

      }
  }