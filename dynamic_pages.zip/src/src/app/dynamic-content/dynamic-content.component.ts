import {  Component, Input, OnInit, OnDestroy, 
  ViewChild, ViewContainerRef, 
  ComponentFactoryResolver, ComponentRef } from '@angular/core';

@Component({
  selector: 'dynamic-content',
  template: `
  <div>
  <template #tpl1>
  <h3>sample template_1...!</h3>
  <button (click)="fun1()" style="background-color:green;">Click Me!!!</button>
  </template>
  
  <template #tpl2>
  <h3>sample template_2...!</h3>
  <button (click)="fun1()" style="background-color:red;">Click Me!!!</button>
  </template>
    <div #container></div>
  </div>
  `,
  styleUrls: ['./dynamic-content.component.css']
})
export class DynamicContentComponent implements OnInit, OnDestroy {

  @ViewChild('container', { read: ViewContainerRef })
  container: ViewContainerRef;

  @ViewChild('tpl1') tpl1;
  @ViewChild('tpl2') tpl2;

  @Input()
  type: string;

  @Input()
  context: any;


  private mappings = {
      'textbox': TextBoxComponent,
      'sample2': DynamicSample2Component
  };

  private componentRef: ComponentRef<{}>;

  constructor(
      private componentFactoryResolver: ComponentFactoryResolver) {
  }

  getComponentType(typeName: string) {
      let type = this.mappings[typeName];
      return type || UnknownDynamicComponent;
  }

  ngOnInit() {
      if (this.type) {
          let componentType = this.getComponentType(this.type);
          
          // note: componentType must be declared within module.entryComponents
          let factory = this.componentFactoryResolver.resolveComponentFactory(componentType);
          this.componentRef = this.container.createComponent(factory);

          // set component context
          let instance = <DynamicComponent> this.componentRef.instance;
          instance.context = this.context;

          /*
          this.container.createEmbeddedView(this.tpl1);
          this.container.createEmbeddedView(this.tpl2);
          */



      }
  }

  fun1(){
    alert("Clicked!!!!!!!!!!");
  }

  ngOnDestroy() {
      if (this.componentRef) {
          this.componentRef.destroy();
          this.componentRef = null;
      }
  }

}

export abstract class DynamicComponent {
  context: any;
}

@Component({
  selector: 'dynamic-sample-1',
  template: `<div>  <label>({{context?.label}}):<input id={{context?.id}} type={{context?.type}} 
   maxLength={{context?.maxChars}} value={{context?.value}}/> </label></div> 
   ---------
  
`
})
export class TextBoxComponent extends DynamicComponent {
 
}

@Component({
  selector: 'dynamic-sample-2',
  template: `<div>Dynamic sample 2 ({{context?.text}})</div>`
})
export class DynamicSample2Component extends DynamicComponent {}

@Component({
  selector: 'unknown-component',
  template: `<div>Unknown component ({{context?.text}})</div>`
})
export class UnknownDynamicComponent extends DynamicComponent {}

