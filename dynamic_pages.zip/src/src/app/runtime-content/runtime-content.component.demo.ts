import { Component,
    ViewChild, ViewContainerRef, ComponentRef,
    Compiler, ComponentFactory, NgModule, ModuleWithComponentFactories, ComponentFactoryResolver } from '@angular/core';
    import { CommonModule } from '@angular/common';
    
@Component({
    selector: 'runtime-content-demo',
    template: `
        <div>
            <h2>Runtime content</h2>
            <runtime-content></runtime-content>
        </div>
    `
  })
  export class RuntimeContentComponentDemo {
  }