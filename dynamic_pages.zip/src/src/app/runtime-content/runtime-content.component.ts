import { Component,
  ViewChild, ViewContainerRef, ComponentRef,
  Compiler, ComponentFactory, NgModule, ModuleWithComponentFactories, ComponentFactoryResolver } from '@angular/core';
  import { CommonModule } from '@angular/common';
  import { DynamicContentComponent,TextBoxComponent, 
    DynamicSample2Component, 
    UnknownDynamicComponent  } from '../dynamic-content/dynamic-content.component';

@Component({
  selector: 'runtime-content',
  template: `
  <div>
    <h3>Template</h3>
    
    <button (click)="compileTemplate()">Compile</button>
    <h3>Output</h3>
    <div #container></div>
  </div>
  `,
  styleUrls: ['./runtime-content.component.css']
})
export class RuntimeContentComponent  {
    
      template: string = '<div>  <label>({{context.label}}):<input id={{context.id}} type={{context.type}} maxLength={{context.maxChars}} value={{context.value}}/> </label></div>';
      

      @ViewChild('container', { read: ViewContainerRef })
      container: ViewContainerRef;
     
      private componentRef: ComponentRef<{}>;
  
      constructor(
          private componentFactoryResolver: ComponentFactoryResolver,
          private compiler: Compiler) {
      }
  
      compileTemplate() {
          
          let metadata = {
              selector: `runtime-component-sample`,
              template: this.template
          };
  
          let factory = this.createComponentFactorySync(this.compiler, metadata, null);
          
          if (this.componentRef) {
              this.componentRef.destroy();
              this.componentRef = null;
          }
          this.componentRef = this.container.createComponent(factory);
      }
  
      private createComponentFactorySync(compiler: Compiler, metadata: Component, componentClass: any): ComponentFactory<any> {
        
          const cmpClass = componentClass || class RuntimeComponent { name: string = 'Pramod' 
          context = {
            text: 'test',
            type:'textbox',
            seq: "1",
            id: "ARXELOZ-LOST-COUNTRY",
            control: "Hidden",
            reqIndicator: "false",
            maxChars: "3",
            value: "No",
            label: "Country Of Loss"
          };
        };
          const decoratedCmp = Component(metadata)(cmpClass);
  
          @NgModule({ imports: [CommonModule], declarations: [decoratedCmp] })
          class RuntimeComponentModule { }
  
          let module: ModuleWithComponentFactories<any> = compiler.compileModuleAndAllComponentsSync(RuntimeComponentModule);
          return module.componentFactories.find(f => f.componentType === decoratedCmp);
      }
  
}
