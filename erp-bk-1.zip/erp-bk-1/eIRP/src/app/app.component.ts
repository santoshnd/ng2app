import { Component, OnInit } from '@angular/core';

import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';

// import { NGXLogger } from 'ngx-logger';

export class IState {
  name: string;
  abbrev: string;

}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'] // ,
  // providers: [NGXLogger]
})
export class AppComponent implements OnInit {
  title = 'Angular Test Application';

  error: any;
  headers: string[];
  configUrl: string;

  selectedState: IState = { name: 'Colorado', abbrev: 'CO' };
  states: IState[] = [
    { name: 'Arizona', abbrev: 'AZ' },
    { name: 'California', abbrev: 'CA' },
    { name: 'Colorado', abbrev: 'CO' },
    { name: 'New York', abbrev: 'NY' },
    { name: 'Pennsylvania', abbrev: 'PA' }
  ];

  constructor(/* private logger: NGXLogger, */ dm: DomSanitizer, private http: HttpClient) {

  }

  ngOnInit() {
    console.log('Inside App Init');
    // this.configUrl = 'localhost';
    this.configUrl = 'http://localhost:4200/formb';

    this.http.get(this.configUrl, { observe: 'response' })
      .subscribe(resp => {
        // display its headers
        const keys = resp.headers.keys();
        this.headers = keys.map(key =>
          `${key}: ${resp.headers.get(key)}`);

          console.log('Print Headers:');
          console.log(this.headers);

        // access the body directly, which is typed as `Config`.
        const config = { ...resp.body };
        console.log('Print Body:');
        console.log(config);
      });

  }

  /* ******* DOM Sanitizer security POC ************************************
   // For example, a user/attacker-controlled value from a URL.
   htmlSnippet = 'Template <script>alert("0wned")</script> <b>Syntax</b>';
   *********************************************************************** */

  onSubmit() {
    // alert('Submit Clicked !');

    /*
      console.log('test log-1');
      this.logger.debug('Your log message goes here');
      console.log('test log-2');
      this.logger.debug('Multiple', 'Argument', 'support');
      console.log('test log-3');
      */

    alert(this.selectedState.name);
  }

}
