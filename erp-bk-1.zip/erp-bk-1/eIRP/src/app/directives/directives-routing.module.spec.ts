import { DirectivesRoutingModule } from './directives-routing.module';

describe('DirectivesRoutingModule', () => {
  let directivesRoutingModule: DirectivesRoutingModule;

  beforeEach(() => {
    directivesRoutingModule = new DirectivesRoutingModule();
  });

  it('should create an instance', () => {
    expect(directivesRoutingModule).toBeTruthy();
  });
});
