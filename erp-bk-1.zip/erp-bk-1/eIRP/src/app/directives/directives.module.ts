import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormbComponent } from './formb/formb.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    FormbComponent]
})
export class DirectivesModule { }
