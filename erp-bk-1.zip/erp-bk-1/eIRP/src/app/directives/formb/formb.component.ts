import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-formb',
  templateUrl: './formb.component.html',
  styleUrls: ['./formb.component.scss']
})
export class FormbComponent implements OnInit {
  error: any;
  headers: string[];
  configUrl: string;

  constructor( private http: HttpClient) {

  }

  ngOnInit() {
    console.log('Inside App Init');
    this.configUrl = 'http://localhost';
    // this.configUrl = 'http://localhost:4200/formb';

    this.http.get(this.configUrl, { observe: 'response' })
      .subscribe(resp => {
        // display its headers
        const keys = resp.headers.keys();
        this.headers = keys.map(key =>
          `${key}: ${resp.headers.get(key)}`);

          console.log('Print Headers:');
          console.log(this.headers);

        // access the body directly, which is typed as `Config`.
        const config = { ...resp.body };
        console.log('Print Body:');
        console.log(config);
      });
  }

}
