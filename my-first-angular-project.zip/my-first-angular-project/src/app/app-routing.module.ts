import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Bp1AddView1Component }   from './bp1addview1/bp1addview1.component';
import { Bp1AddView2Component }      from './bp1addview2/bp1addview2.component';


const routes: Routes = [
  { path: '', redirectTo: '/Bp1AddView1', pathMatch: 'full' },
  { path: 'Bp1AddView1', component: Bp1AddView1Component },
  { path: 'Bp1AddView2', component: Bp1AddView2Component }

];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}