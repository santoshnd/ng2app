import { Component, ViewChild, ViewContainerRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Tour of Heroes';

  @ViewChild("appcontainer", { read: ViewContainerRef })
  public appcontainerRef: ViewContainerRef;

}

