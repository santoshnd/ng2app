import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';

import { WindowModule } from '@progress/kendo-angular-dialog';

// Import the Animations module
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Import the ButtonsModule
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { AppRoutingModule } from './/app-routing.module';
import { Bp1AddView1Component } from './bp1addview1/bp1addview1.component';
import { Bp1AddView2Component } from './bp1addview2/bp1addview2.component';

@NgModule({
    declarations: [
        AppComponent,
        Bp1AddView1Component,
        Bp1AddView2Component
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,

        WindowModule,

        // Register the modules
        BrowserAnimationsModule,
        ButtonsModule,
        AppRoutingModule
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }