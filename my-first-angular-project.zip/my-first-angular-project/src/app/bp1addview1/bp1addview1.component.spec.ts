import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Bp1addview1Component } from './bp1addview1.component';

describe('Bp1addview1Component', () => {
  let component: Bp1addview1Component;
  let fixture: ComponentFixture<Bp1addview1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Bp1addview1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Bp1addview1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
