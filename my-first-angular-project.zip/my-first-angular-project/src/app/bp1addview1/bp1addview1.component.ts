import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { Bp1AddView2Component }      from '../bp1addview2/bp1addview2.component';
import { WindowService, WindowRef, WindowCloseResult } from '@progress/kendo-angular-dialog';

import { AppComponent } from '../app.component';


@Component({
  selector: 'app-bp1addview1',
  templateUrl: './bp1addview1.component.html',
  styleUrls: ['./bp1addview1.component.scss']
})
export class Bp1AddView1Component implements OnInit {

  constructor(private router:Router, private windowService: WindowService,
     private appComponent: AppComponent ) { }

  ngOnInit() {
  }

  public opened = true;
      public dataSaved = false;
  
      public close() {
        this.opened = false;
      }
  
      public open() {
        this.opened = true;
      }
  
      public onNewWindow(){
        //alert("New Window Button Clicked !");
        //this.router.navigate(['Bp1AddView2']);

         const windowRef = this.windowService.open({
            //appendTo: this.containerRef,
            appendTo: this.appComponent.appcontainerRef,
            title: 'Success!',
            content: Bp1AddView2Component,
            width: 450
            });

        const view2Info = this.windowRef.content.instance;
        //userInfo.name = 'admin';
        //userInfo.age = 42;

        windowRef.result.subscribe((result) => {
          if (result instanceof WindowCloseResult) {
            console.log('WindoClosedResult = ',result);  
            
            alert('Window was closed!');
          }
      });        

      }
  
      public onNameClicked(){
        alert("Name text box clicked!");
      }
  
      public submit() {
          this.dataSaved = true;
          this.close();
      }

}
