import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Bp1addview2Component } from './bp1addview2.component';

describe('Bp1addview2Component', () => {
  let component: Bp1addview2Component;
  let fixture: ComponentFixture<Bp1addview2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Bp1addview2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Bp1addview2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
