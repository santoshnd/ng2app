import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';


@Component({
  selector: 'app-bp1addview2',
  templateUrl: './bp1addview2.component.html',
  styleUrls: ['./bp1addview2.component.scss']
})
export class Bp1AddView2Component implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  public opened = true;
  public dataSaved = false;

  public close() {
    this.opened = false;
    
   }

  public open() {
    this.opened = true;
  }

  public onNewWindow(){
    //alert("New Window Button Clicked !");
    this.router.navigate(['Bp1AddView1']);
  }

  public onNameClicked(){
    alert("Name text box clicked!");
  }

  public submit() {
      this.dataSaved = true;
      this.close();
  }

}
